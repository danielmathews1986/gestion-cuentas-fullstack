package com.daniel.springboot.app.services;

import com.daniel.springboot.app.model.entities.Transaccion;

import java.util.List;

public interface TransaccionService {
    List<Transaccion> obtenerTodas();
    List<Transaccion> obtenerPorCuentaId(Long cuentaId);
    Transaccion crearTransaccion(Long cuentaId, Transaccion transaccion);
    void eliminarTransaccion(Long id);
}
