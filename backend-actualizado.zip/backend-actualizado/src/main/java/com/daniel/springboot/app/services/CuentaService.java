package com.daniel.springboot.app.services;

import com.daniel.springboot.app.model.entities.Cuenta;

import java.util.List;
import java.util.Optional;

public interface CuentaService {

    List<Cuenta> obtenerTodas();

    Optional<Cuenta> obtenerPorId(Long id);

    Cuenta crearCuenta(Cuenta cuenta);

    Cuenta actualizarCuenta(Long id, Cuenta cuentaActualizada);

    void eliminarCuenta(Long id);

}
