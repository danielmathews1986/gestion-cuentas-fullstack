package com.daniel.springboot.app.services;
import com.daniel.springboot.app.model.entities.Product;
import com.daniel.springboot.app.respositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService{

    @Autowired
    private ProductRepository repository;

    @Override
    @Transactional(readOnly = true)
    public List<Product> findAlL() {
        return (List<Product>) repository.findAll();
    }
}
