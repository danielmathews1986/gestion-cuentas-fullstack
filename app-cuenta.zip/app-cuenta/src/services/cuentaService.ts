import type { Cuenta } from "../types/Cuenta";

const API_URL = 'http://localhost:8080/api/cuentas';

export const getCuentas = async (): Promise<Cuenta[]> => {
    const res = await fetch(API_URL);
    if(!res.ok) throw new Error('ERROR AL OBTENER LA CUENTA');
    return await res.json();
}

export const getCuenta = async (id: number): Promise<Cuenta> => {
    const res = await fetch(`${API_URL}/${id}`);
    if(!res.ok) throw new Error('ERROR AL OBTENER CUENTA')
        return await res.json();
}

export const crearCuenta = async (cuenta: Cuenta): Promise<Cuenta> => {
    const res = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json'},
        body: JSON.stringify(cuenta),
    });
    if(!res.ok) throw new Error('ERROR AL CREAR CUENTA');
    return await res.json();
}

export const actualizarCuenta = async (id:number, cuenta: Cuenta): Promise<Cuenta>=>{

    console.log("xx", id, cuenta)
    
    const res = await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(cuenta),
    });
    if(!res.ok) throw new Error('ERROR AL ACTUALIZAR CUENTA');
    return await res.json();
}

export const eliminarCuenta = async (id:number): Promise<void> => {
    const res = await fetch(`${API_URL}/${id}`, {
        method: 'DELETE',
    });
    if(!res.ok) throw new Error('ERROR A ELIMINAR CUENTA');
}