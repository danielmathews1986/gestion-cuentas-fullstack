package com.daniel.springboot.app.controllers;

public class HelloController {
}
