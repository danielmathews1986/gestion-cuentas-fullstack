package com.daniel.springboot.app.respositories;

import com.daniel.springboot.app.model.entities.Cuenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CuentaRepository extends JpaRepository<Cuenta, Long> {
}
