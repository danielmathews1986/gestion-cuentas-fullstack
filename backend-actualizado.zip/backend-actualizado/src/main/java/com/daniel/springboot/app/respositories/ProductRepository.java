package com.daniel.springboot.app.respositories;

import com.daniel.springboot.app.model.entities.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product, Long> {

}
