package com.daniel.springboot.app.services;

import com.daniel.springboot.app.model.entities.Product;

import java.util.List;

public interface ProductService {
    List<Product> findAlL();
}
