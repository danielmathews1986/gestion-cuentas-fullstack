export const TransaccionModal = () => {

    return(
        <>
        </>
    )
}