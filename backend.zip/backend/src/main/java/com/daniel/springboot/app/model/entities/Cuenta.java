package com.daniel.springboot.app.model.entities;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Cuenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double saldo;

    private String tipoCuenta;

    @Embedded
    private TitularCuenta titularCuenta;

    @OneToMany(mappedBy = "cuenta", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonManagedReference
    private List<Transaccion> historialTransacciones = new ArrayList<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public TitularCuenta getTitularCuenta() {
        return titularCuenta;
    }

    public void setTitularCuenta(TitularCuenta titularCuenta) {
        this.titularCuenta = titularCuenta;
    }

    public List<Transaccion> getHistorialTransacciones() {
        return historialTransacciones;
    }

    public void setHistorialTransacciones(List<Transaccion> historialTransacciones) {
        this.historialTransacciones.clear(); // evita duplicados

        if (historialTransacciones != null) {
            for (Transaccion t : historialTransacciones) {
                t.setCuenta(this); // aquí está el punto clave
                this.historialTransacciones.add(t);
            }
        }
    }


}
