import React, { useState } from "react";
interface Cuenta {
    id: number;
    saldo: number;
    tipoCuenta: string;
    titularCuenta: {
        nombre: string;
        direccion: string;
    }
}

interface ICuentaProps {
    cuentas: Cuenta[];
    onEdit: (data: any) => void;
    onDelete: (id: number) => void;
    onDetail: (id: number) => void;
}


const CuentaList: React.FC<ICuentaProps> = ({ cuentas, onEdit, onDelete, onDetail }) => {

    return (
        <>
            <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
                <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">
                                ID
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Saldo
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Tipo
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Nombre
                            </th>
                            <th scope="col" className="px-6 py-3">
                                Direccion
                            </th>
                            <th scope="col" className="px-6 py-3">
                                ACTIONS
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        {cuentas.map((x) =>

                            <tr key={x.id} className="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700 border-gray-200">
                                <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    {x.id}
                                </th>
                                <td className="px-6 py-4">
                                    {x.saldo}
                                </td>
                                <td className="px-6 py-4">
                                    {x.tipoCuenta}
                                </td>
                                <td className="px-6 py-4">
                                    {x.titularCuenta?.nombre}
                                </td>
                                <td className="px-6 py-4">
                                    {x.titularCuenta?.direccion}
                                </td>
                                <td className="px-6 py-4">
                                    <a href="#" className="font-medium text-blue-600 dark:text-blue-500 hover:underline" onClick={() => onEdit(x)}> editar / </a>
                                    <a href="#" className="font-medium text-blue-600 dark:text-blue-500 hover:underline" onClick={() => onDetail(x.id)}> detalle </a>
                                </td>
                            </tr>
                        )}

                    </tbody>
                </table>
            </div>

        </>
    )
}

export default CuentaList;