package com.daniel.springboot.app.services;

import com.daniel.springboot.app.model.entities.Cuenta;
import com.daniel.springboot.app.model.entities.Transaccion;
import com.daniel.springboot.app.respositories.CuentaRepository;
import com.daniel.springboot.app.respositories.TransaccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TransaccionServiceImpl implements TransaccionService{

    @Autowired
    private TransaccionRepository transaccionRepository;

    @Autowired
    private CuentaRepository cuentaRepository;

    @Override
    public List<Transaccion> obtenerTodas() {
        return transaccionRepository.findAll();
    }

    @Override
    public List<Transaccion> obtenerPorCuentaId(Long cuentaId) {
        return transaccionRepository.findByCuentaId(cuentaId);
    }

    @Override
    public Transaccion crearTransaccion(Long cuentaId, Transaccion transaccion) {

        Cuenta cuenta = cuentaRepository.findById(cuentaId)
                .orElseThrow(() -> new RuntimeException("CUENTA NO ENCONTRADA"));

        if(transaccion.getTipo().equalsIgnoreCase("deposito")) {
            cuenta.setSaldo(cuenta.getSaldo() + transaccion.getMonto());
        } else if( transaccion.getTipo().equalsIgnoreCase("retiro")) {
            if(cuenta.getSaldo() < transaccion.getMonto()) {
                throw new RuntimeException("SALDO INSUFICIENTE PARA EL RETIRO");
            }
            cuenta.setSaldo(cuenta.getSaldo() - transaccion.getMonto());
        } else {
            throw new RuntimeException("TIPO DE TRANSACCION NO VALIDA");
        }

        transaccion.setCuenta(cuenta);
        transaccion.setFecha(LocalDateTime.now());

        cuenta.getHistorialTransacciones().add(transaccion);

        cuentaRepository.save(cuenta);

        return transaccion;
    }

    @Override
    public Transaccion tranferir(Long cuentaOrigenId, Long cuentaDestinoId, double monto) {
        Cuenta origen =  cuentaRepository.findById(cuentaOrigenId)
                .orElseThrow(() -> new RuntimeException("Cuenta origen no encontrado"));

        Cuenta destino = cuentaRepository.findById(cuentaDestinoId)
                .orElseThrow(() -> new RuntimeException("Cuenta con destino no encontrado"));

         if(origen.getSaldo() < monto){
             throw new RuntimeException("Saldo insuficiente");
         }

         origen.setSaldo(origen.getSaldo() - monto);

         destino.setSaldo(destino.getSaldo() + monto );

         Transaccion transaccion = new Transaccion();
         transaccion.setTipo("tranferencia");
         transaccion.setMonto(monto);
         transaccion.setFecha(LocalDateTime.now());
         transaccion.setCuenta(origen);
         transaccion.setCuentaDestino(destino);

         origen.getHistorialTransacciones().add(transaccion);

         cuentaRepository.save(origen);
         cuentaRepository.save(destino);

        return transaccion;
    }

    @Override
    public void eliminarTransaccion(Long id) {
        transaccionRepository.deleteById(id);
    }
}
