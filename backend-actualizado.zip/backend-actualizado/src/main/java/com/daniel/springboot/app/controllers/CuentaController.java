package com.daniel.springboot.app.controllers;

import com.daniel.springboot.app.model.entities.Cuenta;
import com.daniel.springboot.app.model.entities.TitularCuenta;
import com.daniel.springboot.app.respositories.CuentaRepository;
import com.daniel.springboot.app.services.CuentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:5173/")
@RestController
@RequestMapping("api/cuentas")
public class CuentaController {

    @Autowired
    private CuentaService cuentaService;

    @Autowired
    private CuentaRepository cuentaRepository;

    @GetMapping
    public List<Cuenta> obtenerCuentas() {
        return cuentaService.obtenerTodas();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cuenta> obtenerCuentaPorId(@PathVariable Long id) {
        return cuentaService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }


    @PostMapping
    public ResponseEntity<Cuenta> crearCuenta(@RequestBody Cuenta cuenta) {
        return ResponseEntity.ok(cuentaService.crearCuenta(cuenta));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Cuenta> actualizarCuenta(@PathVariable Long id, @RequestBody Cuenta cuentaActualizada) {
        try {
            Cuenta cuenta = cuentaService.actualizarCuenta(id, cuentaActualizada);
            return ResponseEntity.ok(cuenta);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    public ResponseEntity<Cuenta> actualizar(@PathVariable Long id, @RequestBody TitularCuenta nuevoTitular) {
        return cuentaService.obtenerPorId(id).map(cuenta -> {
            cuenta.setTitularCuenta(nuevoTitular);
            return ResponseEntity.ok(cuentaService.actualizarCuenta(id, cuenta));
        } ).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCuenta(@PathVariable Long id) {
        cuentaService.eliminarCuenta(id);
        return ResponseEntity.notFound().build();
    }

}
