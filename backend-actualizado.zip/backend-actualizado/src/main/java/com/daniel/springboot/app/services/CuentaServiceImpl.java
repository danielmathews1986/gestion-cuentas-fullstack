package com.daniel.springboot.app.services;

import com.daniel.springboot.app.model.entities.Cuenta;
import com.daniel.springboot.app.model.entities.Transaccion;
import com.daniel.springboot.app.respositories.CuentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CuentaServiceImpl implements CuentaService{

    @Autowired
    private CuentaRepository cuentaRepository;

    @Override
    public List<Cuenta> obtenerTodas() {
        return cuentaRepository.findAll();
    }

    @Override
    public Optional<Cuenta> obtenerPorId(Long id) {
        return cuentaRepository.findById(id);
    }

    @Override
    public Cuenta crearCuenta(Cuenta cuenta) {
        List<Transaccion> transacciones = cuenta.getHistorialTransacciones();

        if (transacciones != null) {
            for (Transaccion t : transacciones) {
                t.setCuenta(cuenta);
            }
        }

        return cuentaRepository.save(cuenta);
    }


    @Override
    public Cuenta actualizarCuenta(Long id, Cuenta cuentaActualizada) {
        return  cuentaRepository.findById(id).map(cuenta -> {
            cuenta.setSaldo(cuentaActualizada.getSaldo());
            cuenta.setTipoCuenta(cuentaActualizada.getTipoCuenta());
            cuenta.setTitularCuenta(cuentaActualizada.getTitularCuenta());
            cuenta.setHistorialTransacciones(cuentaActualizada.getHistorialTransacciones());
            cuenta.getHistorialTransacciones().forEach(x -> x.setCuenta(cuenta));
            return cuentaRepository.save(cuenta);
        }).orElseThrow(() -> new RuntimeException("CUENTA NO ENCONTRADA"));
    }

    @Override
    public void eliminarCuenta(Long id) {
            cuentaRepository.deleteById(id);
    }
}
