import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom"
import { getCuenta } from "../../services/cuentaService";
import type { Cuenta } from "../../types/Cuenta";

interface CuentaDetail { }

export const CuentaDetail: React.FC<CuentaDetail> = ({ }) => {

    const { id } = useParams();
    const [cuenta, setCuenta] = useState<Cuenta>();

    useEffect(() => {
        if (id) {
            const idConverted = Number(id);
            getCuenta(idConverted)
                .then((data) => {
                    console.log(data)
                    setCuenta(data)
                })
                .catch((err) => console.error("ERROR AL OBTENER CUENTA:", err));
        }


    }, [id])

    if (!cuenta) return <p>Cargando cuenta...</p>

    return (
        <>



            <div className="p-4">

                <Link to="/cuentas">
                    <button type="button" className="mt-3 py-2.5 px-5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-full border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    >volver</button>
                </Link>

                <h2 className="text-4xl font-extrabold text-indigo-900 mt-3 ">Detalle de Cuenta</h2>


                <ul className="mt-3 mb-4 w-48 text-sm font-medium text-gray-900 bg-white border border-gray-200 rounded-lg dark:bg-gray-700 dark:border-gray-600 dark:text-white w-full">
                    <li className="w-full px-4 py-2 border-b border-gray-200 rounded-t-lg dark:border-gray-600"><strong>ID:</strong> {cuenta.id}</li>
                    <li className="w-full px-4 py-2 border-b border-gray-200 dark:border-gray-600"><strong>SALDO:</strong> {cuenta.saldo}</li>
                    <li className="w-full px-4 py-2 border-b border-gray-200 dark:border-gray-600"><strong>TIPO DE CUENTA:</strong> {cuenta.tipoCuenta}</li>
                    <li className="w-full px-4 py-2 rounded-b-lg"><strong>NOMBRE:</strong> {cuenta.titularCuenta.nombre}</li>
                    <li className="w-full px-4 py-2 rounded-b-lg"><strong>DIRECCION:</strong> {cuenta.titularCuenta.direccion}</li>
                </ul>


                <hr />

                <h2 className="text-4xl font-extrabold text-indigo-900 mt-3 mb-3">Historial de Transacciones</h2>


                <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
                    <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                            <tr>
                                <th scope="col" className="px-6 py-3">
                                    ID
                                </th>
                                <th scope="col" className="px-6 py-3">
                                    Tipo
                                </th>
                                <th scope="col" className="px-6 py-3">
                                    Monto
                                </th>
                                <th scope="col" className="px-6 py-3">
                                    Fecha
                                </th>
                                <th scope="col" className="px-6 py-3">
                                    ACTIONS
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {cuenta?.historialTransacciones && cuenta.historialTransacciones.length > 0 ? (
                                cuenta?.historialTransacciones?.map((x, index) => (
                                    <tr key={index} className="odd:bg-white odd:dark:bg-gray-900 even:bg-gray-50 even:dark:bg-gray-800 border-b dark:border-gray-700 border-gray-200">
                                        <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                            {x.id}
                                        </th>
                                        <td className="px-6 py-4">
                                            {x.tipo}
                                        </td>
                                        <td className="px-6 py-4">
                                            {x.monto}
                                        </td>
                                        <td className="px-6 py-4">
                                            {new Date(x.fecha).toLocaleString()}
                                        </td>
                                        <td className="px-6 py-4">
                                            
                                        </td>
                                    </tr>
                                ))
                            ) : (
                                <li className="text-gray-500 italic">
                                    No hay transacciones registradas
                                </li>
                            )}

                        </tbody>
                    </table>
                </div>

            </div>
        </>
    )

}