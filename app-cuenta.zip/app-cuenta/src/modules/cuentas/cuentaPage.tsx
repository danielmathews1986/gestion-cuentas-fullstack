import type React from "react";
import { useEffect, useState } from "react";
import { actualizarCuenta, crearCuenta, getCuentas } from "../../services/cuentaService";
import CuentaList from "./CuentaList";
import type { Cuenta } from "../../types/Cuenta";
import CuentaModal from "../../components/cuentaModal";
import { useNavigate } from "react-router-dom";


const CuentaPage: React.FC = () => {

    const [cuentas, setCuentas] = useState<any>([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [cuentaEdit, setCuentaEdit] = useState<any>(null);
    const navigate = useNavigate();

    const loadData = () => {
        getCuentas().then(setCuentas).catch(console.error);
    }

    useEffect(() => {
        loadData();
    }, []);

    const handleDelete = () => { }

    const createModal = () => {
        setCuentaEdit(null);
        setModalVisible(true);
    }

    const editModal = (data: any) => {
        console.log("cuenta", data)
        setCuentaEdit(data);
        setModalVisible(true);
    }

    const handleDetail = (id: any) => {
        console.log("id", id)
        navigate(`/cuentas/${id}`);
    }


    return (
        <>
            <div className="container mt-5 p-5">

                <h2 className="text-4xl font-extrabold text-indigo-900 mt-3 ">Gestion de cuentas</h2>

                <button type="button" className="mt-3 py-2.5 px-5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-full border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
                    onClick={createModal}>CREAR</button>

                <CuentaList
                    cuentas={cuentas}
                    onEdit={editModal}
                    onDelete={handleDelete}
                    onDetail={handleDetail}
                />

                {modalVisible && (
                    <CuentaModal
                        cuenta={cuentaEdit}
                        onClose={() => setModalVisible(false)}
                        onSave={(cuenta) => {
                            if (cuentaEdit) {
                                actualizarCuenta(cuentaEdit.id!, cuenta).then(() => {
                                    loadData();
                                    setModalVisible(false);
                                })
                            } else {
                                crearCuenta(cuenta).then(() => {
                                    loadData();
                                    setModalVisible(false);
                                })
                            }
                        }}
                    />
                )}

            </div>
        </>
    )
}

export default CuentaPage;