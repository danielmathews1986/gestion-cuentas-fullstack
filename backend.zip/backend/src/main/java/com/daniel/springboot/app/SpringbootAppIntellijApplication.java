package com.daniel.springboot.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAppIntellijApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAppIntellijApplication.class, args);
	}

}
