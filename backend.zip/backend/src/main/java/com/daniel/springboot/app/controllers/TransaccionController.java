package com.daniel.springboot.app.controllers;

import com.daniel.springboot.app.model.entities.Transaccion;
import com.daniel.springboot.app.services.TransaccionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transacciones")
public class TransaccionController {

    @Autowired
    private TransaccionService transaccionService;

    @GetMapping
    public List<Transaccion> obtenerTodas() {
        return transaccionService.obtenerTodas();
    }

    @GetMapping("/cuenta/{cuentaId}")
    public List<Transaccion> obtenerPorCuenta(@PathVariable Long cuentaId) {
        return transaccionService.obtenerPorCuentaId(cuentaId);
    }

    @PostMapping("/cuenta/{cuentaId}")
    public ResponseEntity<Transaccion> crearTransaccion(@PathVariable Long cuentaId, @RequestBody Transaccion transaccion) {
        try {
            Transaccion nueva = transaccionService.crearTransaccion(cuentaId, transaccion);
            return ResponseEntity.ok(nueva);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    public ResponseEntity<Void> eliminarTransaccion(@PathVariable Long id) {
        transaccionService.eliminarTransaccion(id);
        return ResponseEntity.noContent().build();
    }
}
