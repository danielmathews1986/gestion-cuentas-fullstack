export interface TitularCuenta {
    nombre: string;
    direccion:string;
}

export interface Transaccion {
    id?: number;
    tipo: string;
    monto: number;
    fecha: string;
}

export interface Cuenta{
    id?:number;
    saldo:number;
    tipoCuenta:string;
    titularCuenta: TitularCuenta;
    historialTransacciones?: Transaccion[];
}