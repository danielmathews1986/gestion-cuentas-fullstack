
import {BrowserRouter, Routes, Route } from "react-router-dom";
import CuentaList from "./modules/cuentas/CuentaList";
import CuentaPage from "./modules/cuentas/cuentaPage";
import { CuentaDetail } from "./modules/cuentas/CuentaDetail";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/cuentas" element={<CuentaPage/>}/>
        <Route path="/cuentas/:id" element={<CuentaDetail/>}/>
      </Routes>
    </BrowserRouter>
  )
}

export default App
