import React, { useEffect, useState } from "react";

interface Transaccion {
    tipo: string;
    monto: number;
    fecha: string;
}

interface Cuenta {
    id?: number;
    saldo: number;
    tipoCuenta: string;
    titularCuenta: {
        nombre: string;
        direccion: string;
    }
    historialTransacciones: Transaccion[];
}

interface ICuentaProps {
    cuenta?: Cuenta;
    onClose: () => void;
    onSave: (cuenta: Cuenta) => void;
}

const CuentaModal: React.FC<ICuentaProps> = ({ cuenta, onClose, onSave }) => {

    const [form, setForm] = useState<Cuenta>({
        saldo: 0,
        tipoCuenta: "",
        titularCuenta: {
            nombre: "",
            direccion: "",
        },
        historialTransacciones: []
    })

    useEffect(() => {
        if (
            cuenta &&
            typeof cuenta.saldo !== "undefined" &&
            typeof cuenta.tipoCuenta !== "undefined"
        ) {
            console.log("Cuenta recibida en modal", cuenta);

            setForm({
                saldo: cuenta.saldo,
                tipoCuenta: cuenta.tipoCuenta,
                titularCuenta: {
                    nombre: cuenta.titularCuenta?.nombre || "",
                    direccion: cuenta.titularCuenta?.direccion || ""
                },
                historialTransacciones: cuenta.historialTransacciones || [],
                id: cuenta.id
            });
        } else {
            console.warn("cuenta incompleta o vacía", cuenta);
        }
    }, [cuenta]);



    const handleSubmit = (e: any) => {
        e.preventDefault();
        onSave(form);
    }


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;

        if (name === "nombre" || name === "direccion") {
            setForm((prev) => ({
                ...prev,
                titularCuenta: {
                    ...prev.titularCuenta,
                    [name]: value,
                }
            }));
        } else {
            setForm((prev) => ({ ...prev, [name]: value }));
        }
    }


    return (
        <>

            <div className="fixed top-0 left-0 right-0 z-50 flex justify-center items-center w-full h-full bg-black bg-opacity-30">
                <div className="bg-white dark:bg-gray-700 rounded-lg shadow-lg max-w-md">

                    <div className="flex justify-between p-4 border-b border-gray-200 dark:border-gray-600">
                        <h3 className="text-xl font-semibold">
                            {cuenta ? "Editar Cuenta" : "Nueva Cuenta"}
                        </h3>
                        <button onClick={onClose} className="text-gray-400 hover:text-gray-900">
                            ✕
                        </button>
                    </div>

                    <form className="w-500 p-4" onSubmit={handleSubmit}>

                        <div className="mb-5">
                            <label
                                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Saldo</label>
                            <input type="number"
                                id="saldo"
                                name="saldo"
                                value={form.saldo}
                                onChange={handleChange}
                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required />
                        </div>


                        <label className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Select an option</label>
                        <select
                            value={form.tipoCuenta}
                            onChange={handleChange}
                            id="tipoCuenta"
                            name="tipoCuenta"
                            className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                            <option value="">seleccione el tipo de cuenta</option>
                            <option value="CuentaEstandar">cuenta estandar</option>
                            <option value="CuentaPremium">cuenta premium</option>
                        </select>


                        <div className="mb-5">
                            <label
                                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Nombre</label>
                            <input type="text"
                                id="nombre"
                                name="nombre"
                                value={form.titularCuenta.nombre}
                                onChange={handleChange}
                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required />
                        </div>

                        <div className="mb-5">
                            <label
                                className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">direccion</label>
                            <input type="text"
                                id="direccion"
                                name="direccion"
                                value={form.titularCuenta.direccion}
                                onChange={handleChange}
                                className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" required />
                        </div>



                        <button type="submit"

                            className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Guardar</button>




                    </form>
                </div>
            </div>

        </>
    )
}

export default CuentaModal;